// ============================================================
// CentreBlock Designer Extension
// ============================================================
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var _a;
const $ = (id) => document.getElementById(id);
function showStatus(elId, msg, ok = true) {
    const el = $(elId);
    el.textContent = msg;
    el.className = "status show " + (ok ? "ok" : "err");
    setTimeout(() => el.classList.remove("show"), 6000);
}
// ============================================================
// TAB SWITCHING
// ============================================================
document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
        const name = tab.dataset.tab;
        document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
        document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
        tab.classList.add("active");
        $("tab-" + name).classList.add("active");
        if (name === "variables")
            refreshSelection();
    });
});
// ============================================================
// MODE SWITCHING (Create New vs Attach Existing)
// ============================================================
document.querySelectorAll(".mode-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
        const mode = btn.dataset.mode;
        document.querySelectorAll(".mode-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        $("createMode").style.display = mode === "create" ? "block" : "none";
        $("attachMode").style.display = mode === "attach" ? "block" : "none";
        if (mode === "attach")
            loadExistingVariables();
    });
});
// ============================================================
// SETTINGS TAB
// ============================================================
function loadSiteInfo() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const siteInfo = yield webflow.getSiteInfo();
            $("siteInfo").innerHTML =
                "<div><b>Name:</b> " + siteInfo.siteName + "</div>" +
                    "<div><b>Site ID:</b> <code>" + siteInfo.siteId + "</code></div>" +
                    "<div><b>Short name:</b> " + (siteInfo.shortName || "—") + "</div>";
            const saved = JSON.parse(localStorage.getItem("cb_" + siteInfo.siteId) || "{}");
            if (saved.brokerUrl)
                $("brokerUrl").value = saved.brokerUrl;
            if (saved.customerId)
                $("customerId").value = saved.customerId;
            if (saved.audience)
                $("audience").value = saved.audience;
            if (saved.debug !== undefined)
                $("debug").value = String(saved.debug);
        }
        catch (err) {
            $("siteInfo").textContent = "Error: " + err.message;
        }
    });
}
$("testBtn").addEventListener("click", () => __awaiter(this, void 0, void 0, function* () {
    const brokerUrl = $("brokerUrl").value.trim().replace(/\/$/, "");
    if (!brokerUrl) {
        showStatus("status", "Enter broker URL first", false);
        return;
    }
    try {
        const res = yield fetch(brokerUrl + "/health", { headers: { "ngrok-skip-browser-warning": "true" } });
        const data = yield res.json();
        if (data.ok)
            showStatus("status", "✓ Broker reachable (" + data.time + ")");
        else
            showStatus("status", "Broker responded but not OK", false);
    }
    catch (err) {
        showStatus("status", "Cannot reach broker: " + err.message, false);
    }
}));
$("saveBtn").addEventListener("click", () => __awaiter(this, void 0, void 0, function* () {
    const brokerUrl = $("brokerUrl").value.trim().replace(/\/$/, "");
    const customerId = $("customerId").value.trim();
    const secret = $("secret").value.trim();
    const audience = $("audience").value;
    const debug = $("debug").value === "true";
    if (!brokerUrl || !customerId || !secret) {
        showStatus("status", "Broker URL, Customer ID and Secret are all required", false);
        return;
    }
    $("saveBtn").disabled = true;
    $("saveBtn").textContent = "Working…";
    try {
        const siteInfo = yield webflow.getSiteInfo();
        const regRes = yield fetch(brokerUrl + "/register", {
            method: "POST",
            headers: { "Content-Type": "application/json", "ngrok-skip-browser-warning": "true" },
            body: JSON.stringify({
                site_id: siteInfo.siteId,
                secret: secret,
                customer_id: customerId,
                domain: siteInfo.shortName || siteInfo.siteName,
                default_audience: audience,
                debug: debug,
            }),
        });
        if (!regRes.ok) {
            const err = yield regRes.json().catch(() => ({}));
            throw new Error(err.error || "Broker registration failed");
        }
        const snippet = "<script>\n" +
            "window.__CENTREBLOCK_CONFIG__ = {\n" +
            '  siteId: "' + siteInfo.siteId + '",\n' +
            '  brokerUrl: "' + brokerUrl + '",\n' +
            '  audience: "' + audience + '",\n' +
            "  debug: " + debug + ",\n" +
            '  webname: "' + (siteInfo.shortName || "site").toLowerCase() + '"\n' +
            "};\n" +
            "</" + "script>\n" +
            '<script src="' + brokerUrl + '/tracker.js" defer></' + "script>";
        localStorage.setItem("cb_" + siteInfo.siteId, JSON.stringify({
            brokerUrl, customerId, audience, debug,
        }));
        $("snippet").value = snippet;
        $("snippetBox").style.display = "block";
        try {
            yield navigator.clipboard.writeText(snippet);
            showStatus("status", "✓ Saved! Snippet copied to clipboard.");
        }
        catch (_a) {
            showStatus("status", "✓ Saved! Copy the snippet below manually.");
        }
        $("secret").value = "";
    }
    catch (err) {
        showStatus("status", "Failed: " + err.message, false);
    }
    finally {
        $("saveBtn").disabled = false;
        $("saveBtn").textContent = "Save & Generate Snippet";
    }
}));
$("copyBtn").addEventListener("click", () => __awaiter(this, void 0, void 0, function* () {
    const text = $("snippet").value;
    try {
        yield navigator.clipboard.writeText(text);
        showStatus("status", "Copied to clipboard");
    }
    catch (_a) {
        $("snippet").select();
        showStatus("status", "Select all + Ctrl/Cmd+C", false);
    }
}));
// ============================================================
// VARIABLES TAB
// ============================================================
let selectedElement = null;
function readElementText(el) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (typeof el.getTextContent === "function") {
                const t = yield el.getTextContent();
                if (t && typeof t === "string")
                    return t.trim();
            }
        }
        catch (_a) { }
        try {
            if (typeof el.getChildren === "function") {
                const children = yield el.getChildren();
                for (const child of (children || [])) {
                    const c = child;
                    if (c && c.type === "String" && typeof c.getText === "function") {
                        const t = yield c.getText();
                        if (t)
                            return String(t).trim();
                    }
                    if (c && typeof c.getChildren === "function") {
                        try {
                            const grandkids = yield c.getChildren();
                            for (const gk of (grandkids || [])) {
                                const g = gk;
                                if (g && g.type === "String" && typeof g.getText === "function") {
                                    const t = yield g.getText();
                                    if (t)
                                        return String(t).trim();
                                }
                            }
                        }
                        catch (_b) { }
                    }
                }
            }
        }
        catch (_c) { }
        try {
            if (typeof el.getAllText === "function") {
                const t = yield el.getAllText();
                if (t)
                    return String(t).trim();
            }
        }
        catch (_d) { }
        return "";
    });
}
function slugify(s, maxLen = 30) {
    return String(s || "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "")
        .slice(0, maxLen);
}
function buildVariableName(label, tag) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const siteInfo = yield webflow.getSiteInfo();
            const webname = slugify(siteInfo.shortName || "site", 15);
            const labelSlug = slugify(label || "el", 25);
            const tagSlug = slugify(tag || "el", 12);
            let name = labelSlug && labelSlug !== "el"
                ? `${webname}_${labelSlug}`
                : `${webname}_${labelSlug}_${tagSlug}`;
            name = name.replace(/_+/g, "_").replace(/^_|_$/g, "");
            if (name.length > 50)
                name = name.slice(0, 50).replace(/_$/, "");
            if (!name)
                name = "cb_var";
            return name;
        }
        catch (_a) {
            return slugify(label || "cb_var", 40);
        }
    });
}
function refreshSelection() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const elRaw = yield webflow.getSelectedElement();
            if (!elRaw) {
                selectedElement = null;
                $("selectionBox").className = "selection-box empty";
                $("selectionBox").innerHTML =
                    '<div class="sel-label">No element selected</div>' +
                        '<div class="sel-hint">Click an element on the canvas — like a button or link.</div>';
                $("modeToggle").style.display = "none";
                $("createMode").style.display = "none";
                $("attachMode").style.display = "none";
                $("elementActions").style.display = "none";
                return;
            }
            const el = elRaw;
            selectedElement = el;
            const elType = el.type || "Element";
            const elText = yield readElementText(el);
            $("selectionBox").className = "selection-box has-selection";
            $("selectionBox").innerHTML =
                '<div class="sel-label">✓ Element selected</div>' +
                    '<div class="sel-meta">Type: ' + elType +
                    (elText ? '<br>Text: "' + escapeHtml(elText.slice(0, 60)) + '"' : "<br><span style='color:#888'>no readable text — enter label manually</span>") +
                    "</div>";
            // Show mode toggle and default to Create mode
            $("modeToggle").style.display = "flex";
            const activeMode = document.querySelector(".mode-btn.active");
            const mode = (activeMode === null || activeMode === void 0 ? void 0 : activeMode.dataset.mode) || "create";
            $("createMode").style.display = mode === "create" ? "block" : "none";
            $("attachMode").style.display = mode === "attach" ? "block" : "none";
            $("elementActions").style.display = "block";
            // Auto-fill label/name for Create mode
            const labelInput = $("varLabel");
            const nameInput = $("varName");
            if (elText) {
                labelInput.value = elText.slice(0, 80);
                nameInput.value = yield buildVariableName(elText, elType);
                nameManuallyEdited = false;
            }
            else {
                labelInput.value = "";
                nameInput.value = "";
            }
            yield displayExistingAttrs(el);
        }
        catch (err) {
            showStatus("varStatus", "Selection error: " + err.message, false);
        }
    });
}
function escapeHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function displayExistingAttrs(el) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const trigger = typeof el.getCustomAttribute === "function" ? yield el.getCustomAttribute("data-cbtrigger") : null;
            const tags = typeof el.getCustomAttribute === "function" ? yield el.getCustomAttribute("data-cbtags") : null;
            if (trigger || tags) {
                $("existingTriggers").className = "existing has";
                $("existingTriggers").innerHTML =
                    (trigger ? "<b>trigger:</b> " + escapeHtml(trigger) + "<br>" : "") +
                        (tags ? "<b>tags:</b> " + escapeHtml(tags) : "");
                $("removeAttrBtn").style.display = "block";
            }
            else {
                $("existingTriggers").className = "existing";
                $("existingTriggers").textContent = "none";
                $("removeAttrBtn").style.display = "none";
            }
        }
        catch (_a) {
            $("existingTriggers").className = "existing";
            $("existingTriggers").textContent = "none";
            $("removeAttrBtn").style.display = "none";
        }
    });
}
// Auto-update name when label changes
let nameManuallyEdited = false;
$("varName").addEventListener("input", () => { nameManuallyEdited = true; });
$("varLabel").addEventListener("input", () => __awaiter(this, void 0, void 0, function* () {
    if (nameManuallyEdited)
        return;
    const label = $("varLabel").value;
    const tag = (selectedElement === null || selectedElement === void 0 ? void 0 : selectedElement.type) || "el";
    $("varName").value = yield buildVariableName(label, tag);
}));
$("refreshSelBtn").addEventListener("click", () => {
    nameManuallyEdited = false;
    refreshSelection();
});
try {
    (_a = webflow.subscribe) === null || _a === void 0 ? void 0 : _a.call(webflow, "selectedelement", () => {
        if ($("tab-variables").classList.contains("active")) {
            nameManuallyEdited = false;
            refreshSelection();
        }
    });
}
catch (_b) { }
// ============================================================
// CREATE NEW VARIABLE
// ============================================================
$("createVarBtn").addEventListener("click", () => __awaiter(this, void 0, void 0, function* () {
    if (!selectedElement) {
        showStatus("varStatus", "Select an element first", false);
        return;
    }
    const name = $("varName").value.trim();
    const label = $("varLabel").value.trim();
    const weightCustomer = Number($("weightCustomer").value || 15);
    const weightDefault = Number($("weightDefault").value || 15);
    const direction = $("varDirection").value;
    const leavingLink = $("leavingLink").value.trim();
    if (!name) {
        showStatus("varStatus", "Variable name required", false);
        return;
    }
    if (!label) {
        showStatus("varStatus", "Label required", false);
        return;
    }
    if (name.length > 60) {
        showStatus("varStatus", "Variable name too long (max 60)", false);
        return;
    }
    const siteInfo = yield webflow.getSiteInfo();
    const saved = JSON.parse(localStorage.getItem("cb_" + siteInfo.siteId) || "{}");
    const brokerUrl = saved.brokerUrl;
    if (!brokerUrl) {
        showStatus("varStatus", "Configure broker URL in Settings tab first", false);
        return;
    }
    $("createVarBtn").disabled = true;
    $("createVarBtn").textContent = "Creating…";
    try {
        const resp = yield fetch(brokerUrl + "/variable", {
            method: "POST",
            headers: { "Content-Type": "application/json", "ngrok-skip-browser-warning": "true" },
            body: JSON.stringify({
                site_id: siteInfo.siteId,
                name: name,
                label: label,
                weight_for_customer: weightCustomer,
                weight_for_default: weightDefault,
                leaving_link: leavingLink,
                skip_if_exists: true,
            }),
        });
        const data = yield resp.json();
        if (!resp.ok) {
            const detail = data.detail ? " — " + JSON.stringify(data.detail).slice(0, 200) : "";
            throw new Error((data.error || "Broker rejected request") + detail);
        }
        const finalName = data.name || name;
        const msg = data.skipped
            ? `"${finalName}" already exists in CentreBlock — attaching to element`
            : `"${finalName}" created in CentreBlock`;
        // Attach attributes
        yield attachAttributes(finalName, direction, siteInfo.shortName);
        yield displayExistingAttrs(selectedElement);
        showStatus("varStatus", "✓ " + msg + " · attributes attached");
    }
    catch (err) {
        showStatus("varStatus", "Failed: " + err.message, false);
    }
    finally {
        $("createVarBtn").disabled = false;
        $("createVarBtn").textContent = "Create Variable & Attach";
    }
}));
// ============================================================
// ATTACH EXISTING VARIABLE (no CB creation, just HTML attach)
// ============================================================
function loadExistingVariables() {
    return __awaiter(this, void 0, void 0, function* () {
        const select = $("existingVarSelect");
        select.innerHTML = '<option value="">Loading…</option>';
        try {
            const siteInfo = yield webflow.getSiteInfo();
            const saved = JSON.parse(localStorage.getItem("cb_" + siteInfo.siteId) || "{}");
            const brokerUrl = saved.brokerUrl;
            if (!brokerUrl) {
                select.innerHTML = '<option value="">Configure broker URL first</option>';
                return;
            }
            const resp = yield fetch(brokerUrl + "/variables/" + siteInfo.siteId, {
                headers: { "ngrok-skip-browser-warning": "true" },
            });
            const data = yield resp.json();
            if (!resp.ok) {
                select.innerHTML = '<option value="">Error: ' + (data.error || "fetch failed") + '</option>';
                return;
            }
            const variables = data.variables || [];
            if (variables.length === 0) {
                select.innerHTML = '<option value="">No variables yet — create one first</option>';
                return;
            }
            // Deduplicate by name (CB has duplicate rows for customer/default categories)
            const seen = {};
            const unique = [];
            for (const v of variables) {
                // try common field names CB might return
                const n = v.name || v.variableName || v["﻿name"] || "";
                if (n && !seen[n]) {
                    seen[n] = true;
                    unique.push({ name: n });
                }
            }
            select.innerHTML = '<option value="">— Select a variable —</option>' +
                unique.map(v => `<option value="${escapeHtml(v.name)}">${escapeHtml(v.name)}</option>`).join("");
        }
        catch (err) {
            select.innerHTML = '<option value="">Error: ' + err.message + '</option>';
        }
    });
}
$("reloadVarsBtn").addEventListener("click", loadExistingVariables);
$("attachVarBtn").addEventListener("click", () => __awaiter(this, void 0, void 0, function* () {
    if (!selectedElement) {
        showStatus("varStatus", "Select an element first", false);
        return;
    }
    const varName = $("existingVarSelect").value;
    const direction = $("attachDirection").value;
    if (!varName) {
        showStatus("varStatus", "Select a variable from the list", false);
        return;
    }
    $("attachVarBtn").disabled = true;
    $("attachVarBtn").textContent = "Attaching…";
    try {
        const siteInfo = yield webflow.getSiteInfo();
        yield attachAttributes(varName, direction, siteInfo.shortName);
        yield displayExistingAttrs(selectedElement);
        showStatus("varStatus", `✓ "${varName}" attached to element`);
    }
    catch (err) {
        showStatus("varStatus", "Failed: " + err.message, false);
    }
    finally {
        $("attachVarBtn").disabled = false;
        $("attachVarBtn").textContent = "Attach to Selected Element";
    }
}));
// ============================================================
// REMOVE ATTRIBUTES FROM ELEMENT
// ============================================================
$("removeAttrBtn").addEventListener("click", () => __awaiter(this, void 0, void 0, function* () {
    if (!selectedElement)
        return;
    $("removeAttrBtn").disabled = true;
    $("removeAttrBtn").textContent = "Removing…";
    try {
        if (typeof selectedElement.removeCustomAttribute === "function") {
            yield selectedElement.removeCustomAttribute("data-cbtrigger");
            yield selectedElement.removeCustomAttribute("data-cbtags");
        }
        else if (typeof selectedElement.setCustomAttribute === "function") {
            // Fallback: set to empty string
            yield selectedElement.setCustomAttribute("data-cbtrigger", "");
            yield selectedElement.setCustomAttribute("data-cbtags", "");
        }
        else {
            throw new Error("Element doesn't support attribute removal");
        }
        yield displayExistingAttrs(selectedElement);
        showStatus("varStatus", "✓ CB attributes removed from element");
    }
    catch (err) {
        showStatus("varStatus", "Failed: " + err.message, false);
    }
    finally {
        $("removeAttrBtn").disabled = false;
        $("removeAttrBtn").textContent = "🗑️ Remove CB attributes";
    }
}));
// ============================================================
// SHARED HELPER — attach data-cbtrigger + data-cbtags
// ============================================================
function attachAttributes(varName, direction, webname) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!selectedElement)
            throw new Error("No element selected");
        if (typeof selectedElement.setCustomAttribute !== "function") {
            throw new Error("This element type doesn't support custom attributes. Try selecting a wrapper.");
        }
        const cbtags = "page:" + (webname || "site") + ",direction:" + direction;
        yield selectedElement.setCustomAttribute("data-cbtrigger", varName);
        yield selectedElement.setCustomAttribute("data-cbtags", cbtags);
    });
}
// ============================================================
// BOOT
// ============================================================
loadSiteInfo();
